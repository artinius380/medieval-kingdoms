const pool = require('../config/database');

async function updatePlayerResources(playerId) {
    const [rows] = await pool.query(
        `
        SELECT
            pr.player_id,
            pr.minerals,
            pr.updated_at,
            pb.level AS mine_level
        FROM player_resources pr
        JOIN player_buildings pb
            ON pb.player_id = pr.player_id
        JOIN buildings b
            ON b.id = pb.building_id
        WHERE pr.player_id = ?
          AND b.name = 'Mina'
        `,
        [playerId]
    );

    if (rows.length === 0) {
        throw new Error('Recursos o mina no encontrados');
    }

    const resource = rows[0];

    const baseCost = 100;
    const costMultiplier = 1.5;

    const mineCost =
        baseCost * Math.pow(
            costMultiplier,
            resource.mine_level - 1
        );

    const productionPerHour = mineCost * 0.30;

    const now = new Date();
    const lastUpdate = new Date(resource.updated_at);

    const elapsedMilliseconds = now - lastUpdate;

    const elapsedHours =
        elapsedMilliseconds / (1000 * 60 * 60);

    const mineralsProduced =
        productionPerHour * elapsedHours;

    const newMinerals =
        parseFloat(resource.minerals) + mineralsProduced;

    await pool.query(
        `
        UPDATE player_resources
        SET minerals = ?,
            updated_at = ?
        WHERE player_id = ?
        `,
        [newMinerals, now, playerId]
    );

    return {
        minerals: newMinerals,
        updated_at: now
    };
}

async function getPlayerResources(playerId) {
    return await updatePlayerResources(playerId);
}

module.exports = {
    updatePlayerResources,
    getPlayerResources
};