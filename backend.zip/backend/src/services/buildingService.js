const pool = require('../config/database');


// ----------------------------------------
// Calcular información de una edificación
// ----------------------------------------

function calculateBuildingInfo(level) {

    const baseCost = 100;
    const costMultiplier = 1.5;

    const currentBuildingCost =
        baseCost *
        Math.pow(
            costMultiplier,
            level - 1
        );

    // Producción = 30% del coste del nivel actual
    const productionPerHour =
        currentBuildingCost * 0.30;

    // Coste para subir al siguiente nivel
    const upgradeCost =
        currentBuildingCost * costMultiplier;

    return {
        production_per_hour: productionPerHour,
        next_level: level + 1,
        upgrade_cost: upgradeCost
    };
}


// ----------------------------------------
// Obtener todas las edificaciones de un jugador
// ----------------------------------------

async function getPlayerBuildings(playerId) {

    const [rows] = await pool.query(
        `
        SELECT
            pb.building_id,
            b.name,
            pb.level
        FROM player_buildings pb
        JOIN buildings b
            ON b.id = pb.building_id
        WHERE pb.player_id = ?
        ORDER BY pb.building_id
        `,
        [playerId]
    );

    return rows.map(building => {

        const buildingInfo =
            calculateBuildingInfo(building.level);

        return {
            building_id: building.building_id,
            name: building.name,
            level: building.level,
            ...buildingInfo
        };
    });
}


// ----------------------------------------
// Obtener una edificación específica
// ----------------------------------------

async function getPlayerBuilding(playerId, buildingId) {

    const [rows] = await pool.query(
        `
        SELECT
            pb.player_id,
            pb.building_id,
            b.name,
            pb.level
        FROM player_buildings pb
        JOIN buildings b
            ON b.id = pb.building_id
        WHERE pb.player_id = ?
          AND pb.building_id = ?
        `,
        [playerId, buildingId]
    );

    if (rows.length === 0) {
        return null;
    }

    const building = rows[0];

    const buildingInfo =
        calculateBuildingInfo(building.level);

    return {
        player_id: building.player_id,
        building_id: building.building_id,
        name: building.name,
        level: building.level,
        ...buildingInfo
    };
}


module.exports = {
    getPlayerBuildings,
    getPlayerBuilding
};