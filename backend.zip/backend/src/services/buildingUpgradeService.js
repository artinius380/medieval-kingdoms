const pool = require('../config/database');

async function upgradeBuilding(playerId, buildingId) {

    const connection = await pool.getConnection();

    let transactionCommitted = false;

    try {

        await connection.beginTransaction();

        // ----------------------------------------
        // 1. Obtener la edificación
        // ----------------------------------------

        const [buildingRows] = await connection.query(
            `
            SELECT
                pb.player_id,
                pb.building_id,
                pb.level,
                b.name
            FROM player_buildings pb
            JOIN buildings b
                ON b.id = pb.building_id
            WHERE pb.player_id = ?
              AND pb.building_id = ?
            FOR UPDATE
            `,
            [playerId, buildingId]
        );

        if (buildingRows.length === 0) {
            throw new Error('Edificación no encontrada');
        }

        const building = buildingRows[0];


        // ----------------------------------------
        // 2. Obtener recursos
        // ----------------------------------------

        const [resourceRows] = await connection.query(
            `
            SELECT
                player_id,
                minerals,
                updated_at
            FROM player_resources
            WHERE player_id = ?
            FOR UPDATE
            `,
            [playerId]
        );

        if (resourceRows.length === 0) {
            throw new Error('Recursos del jugador no encontrados');
        }

        const resource = resourceRows[0];


        // ----------------------------------------
        // 3. Calcular producción acumulada
        // ----------------------------------------

        const baseCost = 100;
        const costMultiplier = 1.5;

        const currentLevelCost =
            baseCost *
            Math.pow(
                costMultiplier,
                building.level - 1
            );

        // La mina produce el 30% de su coste por hora
        const productionPerHour =
            currentLevelCost * 0.30;

        const now = new Date();

        const lastUpdate =
            new Date(resource.updated_at);

        const elapsedMilliseconds =
            now - lastUpdate;

        const elapsedHours =
            elapsedMilliseconds /
            (1000 * 60 * 60);

        const mineralsProduced =
            productionPerHour * elapsedHours;

        const currentMinerals =
            parseFloat(resource.minerals);

        const updatedMinerals =
            currentMinerals + mineralsProduced;


        // ----------------------------------------
        // 4. Calcular coste del upgrade
        // ----------------------------------------

        const upgradeCost =
            currentLevelCost * costMultiplier;


        // ----------------------------------------
        // 5. Verificar minerales suficientes
        // ----------------------------------------

        if (updatedMinerals < upgradeCost) {

            // Guardamos la producción acumulada
            await connection.query(
                `
                UPDATE player_resources
                SET minerals = ?,
                    updated_at = ?
                WHERE player_id = ?
                `,
                [
                    updatedMinerals,
                    now,
                    playerId
                ]
            );

            // La producción sí se guarda
            await connection.commit();

            transactionCommitted = true;

            // El edificio NO sube de nivel
            const error = new Error(
                `Minerales insuficientes. Necesitas ${upgradeCost} y tienes ${updatedMinerals}`
            );

            error.statusCode = 400;

            throw error;
        }


        // ----------------------------------------
        // 6. Descontar coste del upgrade
        // ----------------------------------------

        const remainingMinerals =
            updatedMinerals - upgradeCost;


        // ----------------------------------------
        // 7. Subir nivel
        // ----------------------------------------

        const newLevel =
            building.level + 1;


        // ----------------------------------------
        // 8. Actualizar recursos
        // ----------------------------------------

        await connection.query(
            `
            UPDATE player_resources
            SET minerals = ?,
                updated_at = ?
            WHERE player_id = ?
            `,
            [
                remainingMinerals,
                now,
                playerId
            ]
        );


        // ----------------------------------------
        // 9. Actualizar edificio
        // ----------------------------------------

        await connection.query(
            `
            UPDATE player_buildings
            SET level = ?
            WHERE player_id = ?
              AND building_id = ?
            `,
            [
                newLevel,
                playerId,
                buildingId
            ]
        );


        // ----------------------------------------
        // 10. Confirmar transacción
        // ----------------------------------------

        await connection.commit();

        transactionCommitted = true;


        // ----------------------------------------
        // 11. Resultado
        // ----------------------------------------

        return {
            player_id: playerId,
            building_id: buildingId,
            building_name: building.name,
            previous_level: building.level,
            new_level: newLevel,
            upgrade_cost: upgradeCost,
            minerals: remainingMinerals,
            updated_at: now
        };

    } catch (error) {

        // Solo hacemos rollback si todavía
        // existe una transacción activa.
        if (!transactionCommitted) {
            await connection.rollback();
        }

        throw error;

    } finally {

        connection.release();

    }
}

module.exports = {
    upgradeBuilding
};