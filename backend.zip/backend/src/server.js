const express = require('express');
const cors = require('cors');

const pool = require('./config/database');

const playerRoutes = require('./routes/playerRoutes');
const buildingRoutes = require('./routes/buildingRoutes');

const {
    validatePlayer
} = require('./middleware/playerMiddleware');

const errorHandler = require('./middleware/errorHandler');

const app = express();

const PORT = 3000;

app.use(cors());
app.use(express.json());



// ----------------------------------------
// Rutas generales
// ----------------------------------------

app.get('/', (req, res) => {
    res.send('Medieval Kingdoms Backend funcionando!');
});


app.get('/test-db', async (req, res, next) => {
    try {
        const [rows] = await pool.query(
            'SELECT 1 AS resultado'
        );

        res.json(rows);

    } catch (error) {
        next(error);
    }
});


// ----------------------------------------
// Rutas de jugadores
// ----------------------------------------

// Rutas de jugadores
app.use(
    '/api/players/:playerId',
    validatePlayer,
    playerRoutes
);


// Rutas de edificaciones
app.use(
    '/api/players/:playerId/buildings',
    validatePlayer,
    buildingRoutes
);


// Middleware global de errores
app.use(errorHandler);


app.listen(PORT, () => {
    console.log(
        `Servidor ejecutándose en http://localhost:${PORT}`
    );
});