const express = require('express');

const {
    getPlayerBuildings,
    getPlayerBuilding
} = require('../services/buildingService');

const {
    upgradeBuilding
} = require('../services/buildingUpgradeService');

const router = express.Router({
    mergeParams: true
});


// ----------------------------------------
// GET /api/players/:playerId/buildings
// ----------------------------------------

router.get('/', async (req, res, next) => {

    try {

        const playerId = req.params.playerId;

        const buildings = await getPlayerBuildings(playerId);

        // Obtener información completa de cada edificio
        const detailedBuildings = await Promise.all(
            buildings.map(async (building) => {

                return getPlayerBuilding(
                    playerId,
                    building.building_id
                );

            })
        );

        res.json({
            player_id: playerId,
            buildings: detailedBuildings
        });

    } catch (error) {

        next(error);

    }

});


// ----------------------------------------
// GET /api/players/:playerId/buildings/:buildingId
// ----------------------------------------

router.get('/:buildingId', async (req, res, next) => {

    try {

        const playerId = req.params.playerId;
        const buildingId = req.params.buildingId;

        const building = await getPlayerBuilding(
            playerId,
            buildingId
        );

        if (!building) {

            const error = new Error(
                'Edificio no encontrado'
            );

            error.statusCode = 404;

            throw error;
        }

        res.json(building);

    } catch (error) {

        next(error);

    }

});


// ----------------------------------------
// POST /api/players/:playerId/buildings/:buildingId/upgrade
// ----------------------------------------

router.post('/:buildingId/upgrade', async (req, res, next) => {

    try {

        const playerId = req.params.playerId;
        const buildingId = req.params.buildingId;

        const result = await upgradeBuilding(
            playerId,
            buildingId
        );

        res.json(result);

    } catch (error) {

        next(error);

    }

});


module.exports = router;